# Mechanica V2 — saved checkpoint, work paused

User requested “Save and pause” on 20 September 2026. Do not continue implementation until asked.

## Current state

V1 was delivered and the user found it sluggish and unintuitive. V2 is a substantive interaction/performance redesign. The source and offline web bundles in this archive contain the current V2 work. No newly verified V2 APK has been delivered yet. The prior V1 APK remains a separate artifact.

Implemented:
- Background physics worker, fixed-step integration, transferable numerical snapshots, interpolated rendering and main-thread fallback.
- Paused scenes stop redrawing; idle browser test measured zero redraws over 800 ms.
- Cheaper shading and geometry, no persistent drawing buffer, bounded ring-buffer trails, incremental scene refresh, reduced graph canvas churn, adaptive resolution.
- Four main tabs: Experiments, Adjust, Build, Measure; full-page experiment gallery and Studio on phones.
- Relevant basic sliders, advanced coordinates/settings tucked away, explicit More space / Show simulation control.
- Direct mass dragging; empty-space orbit; two-tap connection creation.
- Speed, elevation and depth-angle launcher.
- Builders for pendulums, chains, spring strings, a 25-mass / 72-spring fabric, and bungee drops.
- Three additional presets (14 ready-to-run presets plus blank canvas in total).
- Elastic cords that pull only when stretched; planar XY motion lock.
- Reference-run graph overlays and a ghost trajectory, plus distance / elastic-force readout.
- Existing source/app identity, signing key, save format and exports retained. Version code incremented to 2.

## Verification performed so far

- Original 10 physics checks passed after the model changes.
- Five new physics tests passed: slack elastic cord, stretched-cord tension/energy, planar mode, V1 import compatibility, and all five builders finite over 15 simulated seconds.
- V2 browser tests passed initially for worker operation under the Android Content Security Policy, idle rendering, sliders/undo/redo, dragging, launcher, searchable presets, builders, reference runs, CSV, saves, connect, planar mode and responsive layouts.
- A later layout iteration exposed a real event-handler collision: setting data-tab on the app root caused delegated tab selection to rerender controls on every click. This was corrected by using data-screen for root styling. The follow-up browser run completed successfully (exit code 0); all 12 reported groups passed. Full result summary: tests/v2-checkpoint-results.txt.
- Existing source and browser-rendered previews are included. Browser tests are not physical Android tests.

## Remaining before delivering V2 APK

1. Review the final V2 test result; fix remaining defects only when work resumes.
2. Inspect final phone and gallery screenshots after the last layout change. Verify adaptive quality, dragging during playback, reference comparison, save/import/recovery, and panel expansion as needed.
3. Finish V2 documentation. README.md and VERIFICATION.md below this checkpoint still primarily describe V1; STATUS-V2.md is authoritative for this checkpoint.
4. Restore/verify Android toolchain byte integrity. The previous platform android.jar and ECJ jar were truncated, so the first attempted V2 build failed. Replacement downloads were initiated; inspect/re-extract jars before retrying. Build-tool scripts and source/signing key are preserved.
5. Run build-apk.sh with platform 35, build-tools 35.0.0 and ECJ 3.38.0 or JDK 17. Expected output: build/Mechanica-v2.0.apk. Verify signature and same signing certificate as V1, manifest version 2, all offline assets including physics-worker.js, and ZIP alignment.
6. Update final README, verification report and APK hash, then publish the verified V2 APK and replace this source archive with the final source.

## Relevant files

- src/app.js — interface, renderer and worker bridge.
- src/worker.js — background physics loop.
- src/physics.js — integration/constraints/contact/elastic-cord/planar model.
- src/builders.js — system builders and extra presets.
- app/src/main/assets/ — the current bundled web UI and worker.
- tests/v2.test.cjs — latest browser checks, with local test server.
- tests/v2-physics.test.js — new model regressions.
- tests/physics.test.js — original analytic checks.
- tests/ui.test.cjs — legacy V1 interaction script, not valid for V2 navigation.
- previews-v2/ — browser screenshots from the redesign; not Android screenshots.
- signing/mechanica.keystore — original local signing key, needed to install V2 as an update. Keep private.

Rebuild JS: npm ci && npm run bundle.
Physics tests: npm test && node tests/v2-physics.test.js.
Browser tests: install Playwright, then node tests/v2.test.cjs; CHROME_BIN and PLAYWRIGHT_MODULE can point to local installations. The script writes screenshots into ../deliverables/v2.

No physical-device performance guarantee or Android smoke test has been completed.
