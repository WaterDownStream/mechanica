package in.annany.mechanica;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.util.Base64;
import android.webkit.*;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import java.io.*;
import java.util.*;
import org.json.JSONObject;

/** A permission-free, offline Android shell. Only packaged HTTPS assets can execute. */
public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> fileCallback;
 private byte[] pendingBytes;
 private boolean saving;
 private static final int OPEN_FILE=2001, SAVE_FILE=2002;
 private static final String HOST="appassets.androidplatform.net";
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(11,16,25));
  getWindow().setNavigationBarColor(Color.rgb(11,16,25));
  FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(11,16,25));
  web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
  if(android.os.Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(false);root.setOnApplyWindowInsetsListener((view,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});root.requestApplyInsets();}
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setMediaPlaybackRequiresUserGesture(true);s.setSupportZoom(false);s.setTextZoom(100);s.setCacheMode(WebSettings.LOAD_NO_CACHE);s.setGeolocationEnabled(false);
  web.setBackgroundColor(Color.rgb(11,16,25));web.setOverScrollMode(View.OVER_SCROLL_NEVER);web.addJavascriptInterface(new ExportBridge(),"Android");
  web.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
    Uri u=request.getUrl();
    if(!"https".equals(u.getScheme())||!HOST.equals(u.getHost()))return blocked();
    String path=u.getPath();if(path==null||!path.startsWith("/assets/")||path.contains(".."))return blocked();
    path=path.substring(8);if(path.isEmpty())path="index.html";
    try{String mime=path.endsWith(".html")?"text/html":path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":"application/octet-stream";
      Map<String,String> headers=new HashMap<>();headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'none'; worker-src 'self'; object-src 'none'; frame-src 'none'; base-uri 'none'");
      return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,getAssets().open(path));
    }catch(IOException ex){return blocked();}
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return true;}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
    if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
    try{startActivityForResult(intent,OPEN_FILE);}catch(Exception ex){fileCallback.onReceiveValue(null);fileCallback=null;notifyJs("No file picker is available.");}return true;
   }
  });
  web.loadUrl("https://"+HOST+"/assets/index.html");
 }
 private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",new HashMap<>(),new ByteArrayInputStream(new byte[0]));}
 private void notifyJs(String text){runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.onExportResult && window.onExportResult("+JSONObject.quote(text)+")",null);});}
 public final class ExportBridge {
  @JavascriptInterface public void saveFile(String name,String mime,String base64){
   if(name==null||mime==null||base64==null||base64.length()>45000000)return;
   if(!Arrays.asList("application/json","text/csv","image/png").contains(mime))return;
   final String clean=name.replaceAll("[^a-zA-Z0-9._-]","_");
   runOnUiThread(()->{if(saving){notifyJs("Finish the current export first.");return;}try{pendingBytes=Base64.decode(base64,Base64.DEFAULT);saving=true;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime);intent.putExtra(Intent.EXTRA_TITLE,clean);startActivityForResult(intent,SAVE_FILE);}catch(Exception e){pendingBytes=null;saving=false;notifyJs("Could not start export.");}});
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==OPEN_FILE){if(fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);fileCallback=null;}return;}
  if(request==SAVE_FILE){final byte[] bytes=pendingBytes;pendingBytes=null;if(result!=RESULT_OK||data==null||bytes==null){saving=false;notifyJs("Export cancelled.");return;}final Uri uri=data.getData();new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("No output stream");out.write(bytes);notifyJs("File saved.");}catch(Exception e){notifyJs("Could not save file. Try another location.");}finally{runOnUiThread(()->saving=false);}},"MechanicaExport").start();}
 }
 @Override protected void onPause(){if(web!=null){web.evaluateJavascript("window.pauseSimulation && window.pauseSimulation()",null);web.onPause();}super.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("(function(){var m=document.getElementById('modal');if(m&&!m.classList.contains('hidden')){m.classList.add('hidden');return true;}return false;})()",value->{if(!"true".equals(value))super.onBackPressed();});else super.onBackPressed();}
 @Override protected void onDestroy(){if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}if(web!=null){web.removeJavascriptInterface("Android");web.destroy();web=null;}super.onDestroy();}
}
