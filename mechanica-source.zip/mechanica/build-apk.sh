#!/usr/bin/env bash
: "${MECHANICA_SIGNING_PASSWORD:?Set MECHANICA_SIGNING_PASSWORD locally before signing}"
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_JAR:?Set ANDROID_JAR to Android platform 35 android.jar}"
: "${BUILD_TOOLS:?Set BUILD_TOOLS to Android build-tools 35.0.0 directory}"
mkdir -p build/classes build/gen build/dex signing
if [[ ! -f signing/mechanica.keystore ]]; then
 keytool -genkeypair -keystore signing/mechanica.keystore -storepass:env MECHANICA_SIGNING_PASSWORD -keypass:env MECHANICA_SIGNING_PASSWORD -alias mechanica -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Mechanica Local Build, OU=Independent Development, O=Mechanica, C=IN' >/dev/null 2>&1
fi
"$BUILD_TOOLS/aapt" package -f -M app/src/main/AndroidManifest.xml -S app/src/main/res -A app/src/main/assets -I "$ANDROID_JAR" -J build/gen -F build/base.apk
if command -v javac >/dev/null; then
 javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$ANDROID_JAR:$BUILD_TOOLS/core-lambda-stubs.jar" -d build/classes $(find app/src/main/java build/gen -name '*.java')
else
 : "${ECJ_JAR:?Set ECJ_JAR to Eclipse Java compiler jar when javac is unavailable}"
 java -jar "$ECJ_JAR" -encoding UTF-8 -source 8 -target 8 -bootclasspath "$ANDROID_JAR:$BUILD_TOOLS/core-lambda-stubs.jar" -d build/classes $(find app/src/main/java build/gen -name '*.java')
fi
"$BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --min-api 26 --output build/dex $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -u ../unsigned.apk classes.dex)
"$BUILD_TOOLS/zipalign" -f 4 build/unsigned.apk build/aligned.apk
"$BUILD_TOOLS/apksigner" sign --ks signing/mechanica.keystore --ks-key-alias mechanica --ks-pass env:MECHANICA_SIGNING_PASSWORD --key-pass env:MECHANICA_SIGNING_PASSWORD --out build/Mechanica-v2.0.apk build/aligned.apk
"$BUILD_TOOLS/apksigner" verify --verbose build/Mechanica-v2.0.apk
