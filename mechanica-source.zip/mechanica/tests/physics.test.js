import assert from 'node:assert/strict';
import {Physics,body,defaults,validate} from '../src/physics.js';
import {presets} from '../src/presets.js';
const scene=(bodies,links=[],world={})=>({version:1,name:'Test',bodies,links,world:{...defaults(),floor:false,collisions:false,...world}});
let passed=0;function test(name,fn){try{const detail=fn();passed++;console.log(`PASS ${name}${detail?' · '+detail:''}`)}catch(e){console.error('FAIL '+name);throw e}}
function run(s,seconds){for(let i=0;i<Math.round(seconds*s.world.hz);i++)s.step();}
const near=(a,b,tol)=>assert.ok(Math.abs(a-b)<=tol,`${a} ≠ ${b} (tol ${tol})`);
test('Ballistic trajectory matches analytic result',()=>{const s=new Physics(scene([body(1,[0,20,1],{v:[2,3,-1]})]));run(s,1);near(s.bodies[0].p[0],2,1e-9);near(s.bodies[0].p[1],18.095,1e-8);near(s.bodies[0].p[2],0,1e-9);near(s.bodies[0].v[1],-6.81,1e-8);return 'position error < 10⁻⁸ m'});
test('Harmonic oscillator period and energy',()=>{const s=new Physics(scene([body(1,[0,0,0],{fixed:true}),body(2,[3,0,0])],[{a:1,b:2,type:'spring',length:2,k:4,damping:0}],{gravity:[0,0,0]}));const e0=s.energy().total;run(s,Math.PI);near(s.bodies[1].p[0],3,1e-4);near(s.energy().total,e0,1e-4);return 'one-period error < 10⁻⁴ m'});
test('Elastic collision conserves momentum and energy',()=>{const s=new Physics(presets.find(p=>p.name==='Collision bench').make());const e=s.energy().total,p0=s.bodies.reduce((sum,b)=>sum+b.mass*b.v[0],0);run(s,2);near(s.energy().total,e,1e-8);near(s.bodies.reduce((sum,b)=>sum+b.mass*b.v[0],0),p0,1e-8);near(s.bodies[0].v[0],1,1e-8);near(s.bodies[1].v[0],4,1e-8)});
test('Ground contact respects floor',()=>{const s=new Physics(scene([body(1,[0,2,0],{radius:.3})],[],{floor:true,restitution:.6}));run(s,10);assert.ok(s.bodies[0].p[1]>=.3-1e-8)});
test('Rigid pendulum constraint holds',()=>{const s=new Physics(presets.find(p=>p.name==='Spherical pendulum').make());const e0=s.energy().total;run(s,10);const [a,b]=s.bodies;near(Math.hypot(...b.p.map((x,i)=>x-a.p[i])),4,1e-6);assert.ok(Math.abs(s.energy().total-e0)/Math.abs(e0)<.001);return `energy change ${((s.energy().total-e0)/Math.abs(e0)*100).toFixed(6)}% / 10 s`});
test('Rope permits slack',()=>{const s=new Physics(scene([body(1,[0,3,0],{fixed:true}),body(2,[0,2,0])],[{a:1,b:2,type:'rope',length:2,k:30,damping:0}],{gravity:[0,0,0]}));run(s,1);near(s.bodies[1].p[1],2,1e-8)});
test('Two-body gravity conserves momentum / bounded energy',()=>{const s=new Physics(presets.find(p=>p.name==='Binary system').make());const e=s.energy().total;run(s,20);near(s.bodies.reduce((a,b)=>a+b.mass*b.v[2],0),0,1e-8);assert.ok(Math.abs((s.energy().total-e)/e)<1e-4);return `relative energy change ${Math.abs((s.energy().total-e)/e).toExponential(2)}`});
test('Drag dissipates energy',()=>{const s=new Physics(scene([body(1,[0,0,0],{v:[3,0,0]})],[],{gravity:[0,0,0],drag:.5}));const e=s.energy().total;run(s,2);assert.ok(s.energy().total<e);near(s.bodies[0].v[0],3/Math.E,.003)});
test('All 12 presets remain finite for 15 seconds',()=>{for(const p of presets){const s=new Physics(p.make());run(s,15);for(const b of s.bodies)assert.ok([...b.p,...b.v].every(Number.isFinite));}});
test('Malformed imports rejected',()=>{const s=presets[0].make();s.bodies[0].mass=0;assert.throws(()=>validate(s));const s2=presets[0].make();s2.links[0].a=999;assert.throws(()=>validate(s2));const s3=presets[0].make();s3.world.hz=0;assert.throws(()=>validate(s3));});
console.log(`\n${passed} physics / validation tests passed.`);
