> **V2 WORK IN PROGRESS — SAVED AND PAUSED.** See [STATUS-V2.md](STATUS-V2.md) for the current implementation and remaining work. The older V1 documentation below has not yet been fully updated. No verified V2 APK is included.

# Mechanica 1.0

An offline Android 3D classical-mechanics sandbox. Package: `in.annany.mechanica`.

## Install

Open `Mechanica-v1.0.apk` on an Android 8.0+ device with a WebGL2-capable Android System WebView. Allow installation from the app you use to open the APK if Android asks. The APK is signed for sideloading, requires no network or storage permissions, and contains no ads, accounts, analytics, or remote assets.

Start with **Explore**. Pick a preset, press Play, and open **Build** to edit masses and connections. Use **World** for gravity, drag, contacts, and solver accuracy. **Analyse** contains graphs, CSV export, and rewind. **Studio** saves scenes and controls the view.

## Included

- 12 fully editable experiments: elastic pendulum, projectile, spherical pendulum, double pendulum, coupled oscillators, orbit, binary system, collisions, suspended chain, inclined plane, driven resonance, and blank canvas.
- Up to 64 spherical masses and 128 spring, rod, or rope connections.
- Per-mass position, velocity, mass, radius, colour, fixed state, constant force, and sinusoidal force amplitude/frequency/phase.
- Direct translation gizmo, orbit/pan/zoom, camera presets, focus/follow, labels, trajectories, velocity and applied-force arrows.
- Uniform and mutual gravity, linear drag, restitution, floor friction, adjustable inclined plane.
- Fixed steps at 120/240/480 Hz, configurable constraint iterations, speed 0.1×–4×, single-step, reset, edit undo/redo.
- Energy, position, velocity, speed, and phase-space plots; latest 3,000 samples at 20 Hz; rewind up to 600 frames (~30 simulation seconds).
- Named local saves, recovery snapshot, validated JSON import/export, CSV export, image export through Android's system picker.
- Adjustable panel height on phones, expandable viewport, desktop/tablet layout, in-app guide.

## Source layout

- `src/physics.js`: independent physics and validation module.
- `src/presets.js`: reproducible starting scenes.
- `src/app.js`: UI, scene editor, Three.js renderer, analysis and persistence.
- `app/src/main/assets/`: complete bundled offline application, including HTML/CSS/JS.
- `app/src/main/java/`: native Activity, secure local HTTPS asset serving, file import/export bridge, lifecycle handling.
- `tests/`: analytic physics tests and browser interaction tests.
- `example-scenes/`: all presets as importable JSON.
- Release signing keys are excluded. Supply your own local signing key to create signed Android releases.

## Rebuild the interface

Node.js 20+ recommended:

```sh
npm ci
npm run bundle
npm test
```

The checked-in `app.js` is already bundled. For a browser preview:

```sh
python3 -m http.server 8000 --directory app/src/main/assets
```

Open http://localhost:8000. Browser exports use standard downloads; Android exports use the Storage Access Framework.

## Build APK without Gradle

Install JDK 17, Android SDK platform 35, and Android build-tools 35.0.0. Then:

```sh
export ANDROID_JAR="$ANDROID_HOME/platforms/android-35/android.jar"
export BUILD_TOOLS="$ANDROID_HOME/build-tools/35.0.0"
./build-apk.sh
```

Output: `build/Mechanica-v1.0.apk`.

Release signing credentials must be supplied locally and are not included.

A conventional Android Gradle project is also included for Android Studio (AGP 8.7.3, Gradle 8.9, JDK 17). There is no bundled Gradle wrapper or SDK. The Gradle route is provided for convenience; the delivered APK was built with `build-apk.sh`.

## Browser tests

Install Playwright separately for UI tests:

```sh
npm install --no-save playwright
npx playwright install chromium
node tests/ui.test.cjs
```

`CHROME_BIN` can select a Chromium executable, `PLAYWRIGHT_MODULE` can select an existing module, and `OUTPUT_DIR` selects the screenshot directory. Tests serve the UI themselves on localhost:8766. They cover startup, play/pause, editing, undo/redo, connections, world settings, presets, plots, rewind, local saves, CSV/JSON export, JSON import, camera controls, and responsive layouts.

## Physics model and limits

SI units throughout, with a configurable numerical G. Default G=1 is intentionally for small visible systems, not 6.6743e-11. Gravity uses Plummer softening. Smooth motion uses velocity Verlet; rods and taut ropes use SHAKE/RATTLE-style position and velocity constraints. Collisions use impulses with configurable restitution. The floor has approximate Coulomb sliding friction; mass-to-mass contacts are frictionless.

Bodies have no orientation, spin, angular inertia, or rolling dynamics. There is no general mesh collision, gears, rigid compound bodies, fluids, or finite-element solids. Rods/ropes are massless. High-speed contacts are discrete and can tunnel. The constraint solver can introduce numerical error, especially with conflicting contacts or taut networks. Not a certified engineering solver.

Energy shows kinetic + uniform-gravity + spring + softened mutual-gravity potential. Applied-force arrows exclude constraint/contact reactions. External drives, drag, and collisions can change total energy. Fixed bodies are omitted from kinetic and uniform-gravity potential sums. Editing starts a new experiment at the current state with clock zero, clearing plots and rewind. Exported scenes are initial conditions, not time-stamped recordings; periodic drives restart at configured phase. CSV exports the retained recorded samples only.

Performance is bounded by scene limits, capped geometry/trails, fixed-step accumulation, selectable render pixel ratio, and a per-frame physics budget. Heavy scenes slow simulation instead of enlarging its integration step. There is no physical-device frame-rate guarantee.

## Verification

See `VERIFICATION.md` for measured checks and remaining device validation. The Android package and signature were verified; Android launch/file-picker behavior has not been exercised on a physical device or emulator in this environment.

Three.js is MIT licensed; its licence is in `licenses/`.

## Release signing

The private release key is excluded from this repository. Set `MECHANICA_SIGNING_PASSWORD` locally and supply your own signing key before creating signed Android releases. Do not commit signing keys or passwords.
