import {body,defaults} from './physics.js';
const colours=['#9bafff','#ffc985','#78ddc2','#ee9dbf'];
const B=(id,p,opt={})=>body(id,p,{radius:.2,color:colours[(id-1)%4],...opt});
const L=(a,b,type,length,k=35,damping=.08)=>({a,b,type,length,k,damping});
export function makeAssembly(type,opt={}){
 const n=Math.max(3,Math.min(16,Math.round(opt.count||8))),len=opt.length||3,k=opt.k||35;
 const s={version:1,name:'',world:{...defaults(),collisions:false},bodies:[],links:[]};
 if(type==='pendulum'){
 const angle=(opt.angle??40)*Math.PI/180;s.name='My pendulum';
 s.bodies=[B(1,[0,len+1.5,0],{fixed:true,radius:.14,name:'Pivot'}),B(2,[len*Math.sin(angle),len+1.5-len*Math.cos(angle),0],{name:'Bob',mass:opt.mass||1,radius:.3})];
 s.links=[L(1,2,opt.elastic?'spring':'rod',len,k)];
 }else if(type==='chain'||type==='wave'){
 s.name=type==='wave'?'Wave on a string':'Hanging chain';const spacing=.65;
 for(let i=0;i<n;i++){
 s.bodies.push(B(i+1,[(i-(n-1)/2)*spacing,4+(type==='wave'&&i===Math.floor(n/2)?1:0),0],{fixed:i===0||i===n-1,mass:.3,radius:.11,name:`Bead ${i+1}`}));
 if(i)s.links.push(L(i,i+1,type==='wave'?'spring':'rope',type==='wave'?spacing:spacing*1.17,k,.02));}
 if(type==='wave'){s.world.gravity=[0,0,0];s.world.floor=false;}else s.world.drag=.04;
 }else if(type==='grid'){
 s.name='Spring fabric';const cols=5,rows=5,gap=.65;
 for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
 const id=y*cols+x+1;s.bodies.push(B(id,[(x-2)*gap,5-y*gap,.1*Math.sin(x+y)],{fixed:y===0&&(x===0||x===cols-1),mass:.15,radius:.065,name:`Node ${id}`}));
 if(x)s.links.push(L(id-1,id,'spring',gap,k,.08));if(y)s.links.push(L(id-cols,id,'spring',gap,k,.08));
 if(y&&x)s.links.push(L(id-cols-1,id,'spring',gap*Math.SQRT2,k*.5,.08));
 if(y&&x<cols-1)s.links.push(L(id-cols+1,id,'spring',gap*Math.SQRT2,k*.5,.08));}
 s.world.drag=.015;s.world.floor=false;
 }else if(type==='bungee'){
 s.name='Bungee drop';s.bodies=[B(1,[0,7,0],{fixed:true,radius:.14,name:'Anchor'}),B(2,[1,6,0],{mass:1,radius:.3,name:'Falling mass'})];s.links=[L(1,2,'bungee',3,22,.1)];s.world.floor=false;
 }
 return s;
}
export const extraPresets=[
 {name:'Wave on a string',tag:'WAVES',icon:'wave',desc:'Send a pulse through connected masses.',theory:'Transverse disturbances travel through a chain of stretched springs. Change stiffness or bead mass and compare the propagation speed.',make:()=>makeAssembly('wave',{count:13,k:45})},
 {name:'Spring fabric',tag:'NETWORKS',icon:'box',desc:'Pull a node in a 25-mass spring network.',theory:'A discrete mass–spring sheet, not a continuum cloth model. Pull a node to excite coupled motion. Diagonal springs resist shear.',make:()=>makeAssembly('grid')},
 {name:'Bungee drop',tag:'ELASTIC CORD',icon:'spring',desc:'A cord that stretches but never pushes.',theory:'Unlike a spring, an elastic cord acts only when extended: F = −k max(ℓ−ℓ₀,0)n, with tension-only damping.',make:()=>makeAssembly('bungee')}
];
