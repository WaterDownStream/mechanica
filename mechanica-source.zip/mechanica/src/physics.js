// SI units; point-mass dynamics with finite spherical contact radii.
export const clone = x => JSON.parse(JSON.stringify(x));
export const defaults = () => ({gravity:[0,-9.81,0],drag:0,floor:true,tilt:0,collisions:true,restitution:.8,friction:.12,mutual:false,G:1,softening:.15,hz:240,iterations:16,planar:false});
export function body(id,p=[0,3,0],opts={}) {return {id,name:`Mass ${id}`,p:[...p],v:[0,0,0],force:[0,0,0],drive:[0,0,0],frequency:1,phase:0,mass:1,radius:.25,fixed:false,color:'#8b9dff',...opts};}
export const length = a=>Math.hypot(...a);
export const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
export const sub=(a,b)=>a.map((v,i)=>v-b[i]);
export function validate(s) {
 if(!s || s.version!==1 || !Array.isArray(s.bodies)||!Array.isArray(s.links)||s.bodies.length>64||s.links.length>128) throw Error('Use a Mechanica scene with at most 64 masses and 128 links.');
 const finite=(v,min,max)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
 const vec=(v,max)=>Array.isArray(v)&&v.length===3&&v.every(x=>finite(x,-max,max));
 let ids=new Set();
 for(const b of s.bodies){if(!Number.isInteger(b.id)||b.id<1||ids.has(b.id)||!vec(b.p,1e5)||!vec(b.v,1e4)||!vec(b.force,1e4)||!vec(b.drive,1e4)||!finite(b.mass,.01,10000)||!finite(b.radius,.03,10)||!finite(b.frequency,0,100)||!finite(b.phase,-360,360)||typeof b.fixed!=='boolean'||typeof b.name!=='string'||b.name.length>60||!/^#[0-9a-f]{6}$/i.test(b.color))throw Error('Invalid mass properties.'); ids.add(b.id);}
 for(const l of s.links)if(!ids.has(l.a)||!ids.has(l.b)||l.a===l.b||!['spring','rod','rope','bungee'].includes(l.type)||!finite(l.length,.01,1e4)||!finite(l.k,.01,10000)||!finite(l.damping,0,100))throw Error('Invalid connection.');
 const w=s.world;if(w&&w.planar===undefined)w.planar=false;if(!w||!vec(w.gravity,1000)||!finite(w.drag,0,100)||!finite(w.tilt,-75,75)||!finite(w.restitution,0,1)||!finite(w.friction,0,2)||!finite(w.G,0,10000)||!finite(w.softening,.01,10)||![120,240,480].includes(w.hz)||!Number.isInteger(w.iterations)||w.iterations<4||w.iterations>40||['floor','collisions','mutual','planar'].some(k=>typeof w[k]!=='boolean'))throw Error('Invalid world settings.');
 if(typeof s.name!=='string'||s.name.length>80)throw Error('Invalid scene name.');
 return clone(s);
}
export class Physics {
 constructor(s){this.load(s);}
 load(s){s=validate(s);this.bodies=s.bodies;this.links=s.links;this.world=s.world;this.name=s.name;this.time=0;this.map=new Map(this.bodies.map(b=>[b.id,b]));this.lastForces=[];}
 snapshot(){return clone({version:1,name:this.name,world:this.world,bodies:this.bodies,links:this.links});}
 forces(){const w=this.world,bs=this.bodies,fs=bs.map(b=>b.p.map((_,j)=>b.mass*w.gravity[j]-w.drag*b.v[j]+b.force[j]+b.drive[j]*Math.sin(2*Math.PI*b.frequency*this.time+b.phase*Math.PI/180))),ix=new Map(bs.map((b,i)=>[b.id,i]));
 for(const l of this.links){if(l.type!=='spring'&&l.type!=='bungee')continue;const a=this.map.get(l.a),b=this.map.get(l.b),d=sub(b.p,a.p),r=length(d);if(r<1e-10)continue;const n=d.map(x=>x/r);let f=l.k*(r-l.length)+l.damping*dot(sub(b.v,a.v),n);if(l.type==='bungee')f=r>l.length?Math.max(0,f):0;for(let j=0;j<3;j++){fs[ix.get(a.id)][j]+=f*n[j];fs[ix.get(b.id)][j]-=f*n[j];}}
 if(w.mutual)for(let i=0;i<bs.length;i++)for(let k=i+1;k<bs.length;k++){const d=sub(bs[k].p,bs[i].p),r2=dot(d,d)+w.softening**2,f=w.G*bs[i].mass*bs[k].mass/r2**1.5;for(let j=0;j<3;j++){fs[i][j]+=f*d[j];fs[k][j]-=f*d[j];}}
 if(w.planar)for(const f of fs)f[2]=0;return fs;
 }
 step(dt=1/this.world.hz){const bs=this.bodies,w=this.world;if(w.planar)for(const b of bs){b.p[2]=0;b.v[2]=0;}const previous=new Map(bs.map(b=>[b.id,[...b.p]]));let f=this.forces();for(let i=0;i<bs.length;i++){let b=bs[i];if(b.fixed){b.v=[0,0,0];continue;}for(let j=0;j<3;j++){b.v[j]+=.5*dt*f[i][j]/b.mass;b.p[j]+=dt*b.v[j];}}
 // SHAKE-like position projection; fold correction into the half-step velocity.
 const old=bs.map(b=>[...b.p]);
 for(let it=0;it<w.iterations;it++)for(const l of this.links){if(l.type==='spring'||l.type==='bungee')continue;const a=this.map.get(l.a),b=this.map.get(l.b),d=sub(b.p,a.p),r=length(d),wa=a.fixed?0:1/a.mass,wb=b.fixed?0:1/b.mass,sum=wa+wb;if(r<1e-10||!sum||(l.type==='rope'&&r<=l.length))continue;const oldD=sub(previous.get(b.id),previous.get(a.id)),oldR2=dot(oldD,oldD),proj=dot(d,oldD),disc=proj*proj-oldR2*(r*r-l.length*l.length);let dir=d,c=(r-l.length)/sum/r;if(oldR2>1e-12&&disc>=0){dir=oldD;c=(r*r-l.length*l.length)/(sum*(proj+Math.sqrt(disc)));if(!Number.isFinite(c))c=0;}for(let j=0;j<3;j++){a.p[j]+=wa*c*dir[j];b.p[j]-=wb*c*dir[j];}}
 for(let i=0;i<bs.length;i++)if(!bs[i].fixed)for(let j=0;j<3;j++)bs[i].v[j]+=(bs[i].p[j]-old[i][j])/dt;
 this.time+=dt;f=this.forces();this.lastForces=f;for(let i=0;i<bs.length;i++)if(!bs[i].fixed)for(let j=0;j<3;j++)bs[i].v[j]+=.5*dt*f[i][j]/bs[i].mass;
 const tilt=w.tilt*Math.PI/180,n=[-Math.sin(tilt),Math.cos(tilt),0];
 for(let pass=0;pass<4;pass++){
 if(w.floor)for(const b of bs){if(b.fixed)continue;const penetration=b.radius-dot(b.p,n);if(penetration>0){for(let j=0;j<3;j++)b.p[j]+=n[j]*penetration;let vn=dot(b.v,n);if(vn<0){const bounce=Math.abs(vn)<.12?0:w.restitution,imp=-(1+bounce)*vn;for(let j=0;j<3;j++)b.v[j]+=imp*n[j];const vt=b.v.map((v,j)=>v-dot(b.v,n)*n[j]),speed=length(vt),factor=speed>0?Math.min(1,w.friction*imp/speed):0;for(let j=0;j<3;j++)b.v[j]-=factor*vt[j];}}}
 if(w.collisions)for(let i=0;i<bs.length;i++)for(let k=i+1;k<bs.length;k++){const a=bs[i],b=bs[k],wa=a.fixed?0:1/a.mass,wb=b.fixed?0:1/b.mass,sum=wa+wb;if(!sum)continue;const d=sub(b.p,a.p),r=length(d),R=a.radius+b.radius;if(r>=R)continue;const nn=r>1e-9?d.map(x=>x/r):[1,0,0];for(let j=0;j<3;j++){a.p[j]-=nn[j]*(R-r)*wa/sum;b.p[j]+=nn[j]*(R-r)*wb/sum;}const vn=dot(sub(b.v,a.v),nn);if(vn<0){const impulse=-(1+w.restitution)*vn/sum;for(let j=0;j<3;j++){a.v[j]-=impulse*nn[j]*wa;b.v[j]+=impulse*nn[j]*wb;}}}
 // RATTLE-like removal of radial velocity for active constraints.
 for(const l of this.links){if(l.type==='spring'||l.type==='bungee')continue;const a=this.map.get(l.a),b=this.map.get(l.b),d=sub(b.p,a.p),r=length(d),wa=a.fixed?0:1/a.mass,wb=b.fixed?0:1/b.mass,sum=wa+wb;if(!sum||r<1e-9||(l.type==='rope'&&r<l.length-1e-5))continue;const n=d.map(v=>v/r),vn=dot(sub(b.v,a.v),n);if(l.type==='rope'&&vn<=0)continue;for(let j=0;j<3;j++){a.v[j]+=wa*vn*n[j]/sum;b.v[j]-=wb*vn*n[j]/sum;}}
 }
 if(bs.some(b=>[...b.p,...b.v].some(v=>!Number.isFinite(v)||Math.abs(v)>1e6)))throw Error('Scene became unstable. Reset, increase accuracy, or reduce stiffness / forces.');
 }
 energy(){const w=this.world,bs=this.bodies;let kinetic=0,potential=0;for(const b of bs){if(!b.fixed){kinetic+=.5*b.mass*dot(b.v,b.v);potential-=b.mass*dot(w.gravity,b.p);}}
 for(const l of this.links)if(l.type==='spring'||l.type==='bungee'){const stretch=length(sub(this.map.get(l.a).p,this.map.get(l.b).p))-l.length;potential+=.5*l.k*(l.type==='bungee'?Math.max(0,stretch):stretch)**2;}
 if(w.mutual)for(let i=0;i<bs.length;i++)for(let j=i+1;j<bs.length;j++)potential-=w.G*bs[i].mass*bs[j].mass/Math.sqrt(dot(sub(bs[i].p,bs[j].p),sub(bs[i].p,bs[j].p))+w.softening**2);
 return {kinetic,potential,total:kinetic+potential};}
}
