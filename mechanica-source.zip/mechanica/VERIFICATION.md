# Mechanica 1.0 — verification

## Physics and validation: 10 passing checks

- Ballistic position after 1 s agrees with analytic constant-gravity motion to <1e-8 m.
- Harmonic oscillator returns to starting position after one period to <1e-4 m; energy within 1e-4 J.
- Two-mass elastic collision preserves momentum/energy and reproduces the analytic final velocities 1 m/s and 4 m/s.
- A falling sphere does not penetrate the floor beyond tolerance.
- Rigid spherical pendulum keeps its 4 m link to <1e-6 m. At 240 Hz over 10 s, measured energy change is approximately -0.000050% for this preset.
- Slack rope does not artificially push masses apart.
- Binary orbit preserves total momentum. Over 20 s, relative energy change is approximately 2.56e-9 for this preset.
- Linear drag dissipates energy and agrees with the expected exponential speed to 0.003 m/s.
- All 12 presets remain finite for 15 simulated seconds each.
- Invalid masses, connection endpoints, and solver settings are rejected on import.

These are specific regression checks, not universal accuracy guarantees.

## Browser interactions: passing

Tested in Chromium 134 with software WebGL rendering at a 412×892 phone viewport and a 1280×800 desktop viewport. Checks cover render/startup, play/pause, reset, adding/editing/connecting masses, undo/redo, gravity/accuracy controls, preset switching, graph modes, rewind branching, CSV downloads, local saves, JSON round trips, view settings, guide, camera controls, and absence of uncaught JavaScript errors. Screenshots were inspected.

## Android package

Built with Android platform 35 / build-tools 35.0.0, ECJ 3.38.0 targeting Java 8, and D8 for min API 26. Verified by apksigner (APK signature schemes v2 and v3) and inspected with aapt. Package contains the launcher Activity, resources, DEX, and all offline assets. No permissions requested.

## Still requires device validation

No physical Android device or Android emulator was available for a launch smoke test. Native file picker/export, OEM WebView behavior, GPU compatibility, background/resume, and installed-app touch performance require an Android-device check. Browser screenshots show the actual bundled UI but are not Android screenshots. OpenGL ES 3 / WebGL2 and an up-to-date Android System WebView are required. APK is a signed sideload build, not a Play Store release.
